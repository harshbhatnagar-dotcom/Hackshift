# Explainable AI for Diabetic Retinopathy Screening

Hackathon research prototype.

Dataset: APTOS 2019 Blindness Detection
Architecture: EfficientNetB0
Classes: No DR, Mild, Moderate, Severe, Proliferative DR

Final fine-tuned model:
Test accuracy: 69.09%
Test macro F1: 0.5155

This model is NOT validated for clinical diagnosis.

Important:
- Original dataset images are NOT included in this ZIP.
- The original dataset ZIP is stored separately in Google Drive.
- Model training and Grad-CAM code currently lives in the Colab notebook.
